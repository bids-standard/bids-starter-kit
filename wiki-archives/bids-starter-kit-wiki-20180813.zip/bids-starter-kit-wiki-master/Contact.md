We have lots of different ways of staying in touch! You can come chat via our 

[gitter channel](https://gitter.im/INCF/bids-starter-kit) 

or 

[slack](https://brainhack.slack.com/messages/C8RG7F6PN/details/). (If you aren't a member of the slack team you can join at [this link](https://brainhack-slack-invite.herokuapp.com)).

We'd love for you to join the mailing list (bids-discussion@googlegroups.com, click [here](https://groups.google.com/forum/#!forum/bids-discussion) to join). You might find some helpful answers and discussions there.

<br>

**Our preferred way to answer questions** is via our forum [Neurostars](https://neurostars.org/tags/bids) (we have a 90%+ answer rate!)

We understand that posting a question on a forum can seem a bit uncertain and intimidating. However, if _you_ have a question it's almost certain that somebody else will too, and this way we can avoid answering the same question multiple times. Even if your question is not well-defined, just post what you have so far and we will be able to point you in the right direction!
