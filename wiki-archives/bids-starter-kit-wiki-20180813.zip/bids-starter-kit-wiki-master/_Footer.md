### Want to add to this wiki? Check out our [contributing guidelines](https://github.com/INCF/bids-starter-kit/blob/master/CONTRIBUTING.md)

### For any questions, please [contact us](https://github.com/INCF/BIDS-Starter-Kit/wiki/Contact)