## 2018
[MEG-BIDS, the brain imaging data structure extended to magnetoencephalography](https://www.nature.com/articles/sdata2018110)

 >G Niso et al (2018)

<br>

[Practical Solutions for Sharing Data and Materials From Psychological Research](http://journals.sagepub.com/doi/abs/10.1177/2515245917746500)

>RO Gilmore et al (2018)

## 2017
[Best practices in data analysis and sharing in neuroimaging using MRI](https://www.nature.com/articles/nn.4500)

>TE Nichols et al (2017)

<br>

[BIDS apps: Improving ease of use, accessibility, and reproducibility of neuroimaging data analysis methods](http://journals.plos.org/ploscompbiol/article?id=10.1371/journal.pcbi.1005209)

>KJ Gorgolewski et al (2017)

## 2016
[The brain imaging data structure, a format for organizing and describing outputs of neuroimaging experiments](https://www.nature.com/articles/sdata201644)
 
 >KJ Gorgolewski et al (2016)