# bids-starter-kit-wiki

This repository is ***only to keep track of updates on the BIDS Starter Kit wiki**.

Please **DO NOT** update any information about BIDS here. Please, instead, go to [INCF/bids-starter-kit/wiki](https://github.com/INCF/bids-starter-kit/wiki) where we will be delighted to receive your contributions.

There's more information about how to contribute to the Starter Kit in our [contributing guidelines](https://github.com/INCF/BIDS-Starter-Kit/blob/master/CONTRIBUTING.md).
