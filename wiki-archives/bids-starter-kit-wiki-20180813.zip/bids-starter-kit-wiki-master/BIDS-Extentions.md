Is your data type not covered in the current BIDS specification?

BIDS extensions extend the BIDS specification to new data types. A list of extensions can be found on the main [BIDS webpage](http://bids.neuroimaging.io/)

Guidelines for contributing to these extensions or starting your own can be found in the [BIDS Contributer Guide](https://docs.google.com/document/d/1pWmEEY-1-WuwBPNy5tDAxVJYQ9Een4hZJM06tQZg8X4/edit)
