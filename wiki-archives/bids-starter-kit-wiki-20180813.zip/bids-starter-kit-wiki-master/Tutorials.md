## BIDS Tutorial Series: 


### [Part 1a: Introductory Walkthrough](http://reproducibility.stanford.edu/bids-tutorial-series-part-1a/)

<br>

### [Part 1b: Automate the Introductory Walkthrough](http://reproducibility.stanford.edu/bids-tutorial-series-part-1b/)

<br>

### [Part 2a: HeuDiConv Walkthrough](http://reproducibility.stanford.edu/bids-tutorial-series-part-2a/)